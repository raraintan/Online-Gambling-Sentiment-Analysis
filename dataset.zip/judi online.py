#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import numpy as np
from scipy.sparse import hstack
from sklearn.feature_extraction.text import CountVectorizer
from sklearn import metrics
from sklearn.model_selection import cross_val_score
from sklearn.svm import SVC

tweets = pd.read_csv("DataJudiOnline.csv")
list(tweets.columns.values)

sentiment_counts = tweets.Sentimen.value_counts()
number_of_tweets = tweets.Index.count()
print(sentiment_counts)

from nltk.probability import FreqDist

fdist = FreqDist(tweets[(tweets.Sentimen == 'negatif')])
print(fdist.most_common(50))


count_vectorizer = CountVectorizer(ngram_range=(1,2))

vectorized_data = count_vectorizer.fit_transform(tweets.Tweets)
indexed_data = hstack((np.array(range(0,vectorized_data.shape[0]))[:,None], vectorized_data))



def sentiment2target(sentiment):
    return {
        'negatif': 0,
        'netral': 1,
        'positif' : 2
    }[sentiment]

targets = tweets.Sentimen.apply(sentiment2target)

from sklearn.model_selection import train_test_split, KFold, cross_val_score

data_train, data_test, targets_train, targets_test = train_test_split(indexed_data, targets, test_size=0.4, random_state=0)
data_train_index = data_train[:,0]
data_train = data_train[:,1:]
data_test_index = data_test[:,0]
data_test = data_test[:,1:]

from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn import svm
from sklearn.multiclass import OneVsRestClassifier

kf =  KFold(n_splits=10, shuffle=True, random_state=1)

print("\n\nSVM:")

clf = OneVsRestClassifier(svm.SVC(gamma=0.01, C=100., probability=True, class_weight='balanced', kernel='linear'))
cros= cross_val_score(clf, data_train, targets_train, scoring='accuracy', cv = kf)
print(cros)
print("Accuracy: " , cros.mean() * 100)



# In[ ]:




